package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Product;
import com.cg.service.IProductService;

@RestController
public class ProductController {
	@Autowired
	IProductService productService;
	@Autowired
	Product product;
	/*
	 * Post Request Used
	 * http://localhost:8083/createproduct
	 */
	@PostMapping(value="/createproduct",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Product createProduct(@RequestBody Product product) {
	Product savedProduct=productService.createProduct(product);
	return savedProduct;
	}
	
	/*
	 * Put Request Used
	 * http://localhost:8083/updateproduct/s01
	 */
@PutMapping(value="/updateproduct/{id}",consumes= {MediaType.APPLICATION_JSON_VALUE})
public void updateProduct(@RequestBody Product product) {
	Product updateProduct=productService.updateProduct(product);
	
}
/*
 * Delete Request Used
 * http://localhost:8083/deletebyproductid/m01
 */
@DeleteMapping("/deletebyproductid/{id}")
public String deleteById(@PathVariable String id) {
	productService.deleteById(id);
	return id +"Deleted";
}
/*
 * Get Request Used
 * http://localhost:8083/viewproducts/i01
 */
@GetMapping("/viewproducts")
public List<Product> viewProducts(){
	return productService.viewProducts();
}
/*
 * Get Request Used
 * http://localhost:8083/findbyproductid/
 */
@GetMapping("/findbyproductid/{id}")
public Product findById(@PathVariable String id) {
	return productService.findById(id);
}

}
