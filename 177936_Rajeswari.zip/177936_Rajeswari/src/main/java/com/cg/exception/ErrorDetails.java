package com.cg.exception;

public class ErrorDetails {
	private String message;
	private String url;
	public ErrorDetails() {
		super();
	}
	
	public ErrorDetails(String message, String url) {
		super();
		this.message = message;
		this.url = url;
	}

	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}

	@Override
	public String toString() {
		return "ErrorDetails [message=" + message + ", url=" + url + "]";
	}
	
}
