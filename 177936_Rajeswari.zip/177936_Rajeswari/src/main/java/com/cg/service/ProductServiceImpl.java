package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Product;
import com.cg.dao.ProductDao;
@Service
public class ProductServiceImpl implements IProductService {
@Autowired
ProductDao productdao;

	@Override
	/*
	 * createProduct method used for adding product details 
	 */
	public Product createProduct(Product product) {
		return productdao.save(product);
	}

	@Override
	/*
	 * updateProduct method used for updating product details  
	 */
	public Product updateProduct(Product product) {
		return productdao.save(product);
	}

	@Override
	/*
	 * deleteById method used for deleting product details by id  
	 */
	public void deleteById(String id) {
		productdao.deleteById(id);
	}

	@Override
	/*
	 * viewProducts method used for viewing all product details
	 */
	public List<Product> viewProducts() {
		return productdao.findAll();
	}

	@Override
	/*
	 * findById method used for finding product details by id and it will show the entire product details 
	 */
	public Product findById(String id) {
		return productdao.findById(id).get();
	}
	

}
