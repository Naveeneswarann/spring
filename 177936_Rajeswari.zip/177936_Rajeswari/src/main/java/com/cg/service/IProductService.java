package com.cg.service;

import java.util.List;

import com.cg.beans.Product;

public interface IProductService {
	public Product createProduct(Product product);
	public Product updateProduct(Product product);
	public void deleteById(String id);
	public List<Product>viewProducts();
	public Product findById(String id);
	

}
