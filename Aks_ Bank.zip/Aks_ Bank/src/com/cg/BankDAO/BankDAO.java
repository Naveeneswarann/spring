package com.cg.BankDAO;



import com.cg.dto.AccountDetails;
import com.cg.util.Collection;

public class BankDAO implements IBankDAO {

	@Override
	public int addcustomer(Integer a, AccountDetails ab) {
		Collection.addcustomer(a,ab);
		return 0;
		
	}

@Override
	public AccountDetails showbalance(int acc) {
		AccountDetails ab=Collection.showbalance(acc);
		return ab;
	}

}
