package com.cg.MainUI;

import java.util.Random;
import java.util.Scanner;


import com.cg.BankService.BankService;
import com.cg.BankService.IBankService;
import com.cg.Exception.BankException;
import com.cg.dto.AccountDetails;
import com.cg.util.Collection;


public class MainUI
{
	//AccountDetails ab=new AccountDetails();
	
	// Scanner sc=null;
  
	public static void main(String[] args)
	{
		 Scanner sc=null;
		 IBankService service=new BankService();
		 // AccountDetails ab=new AccountDetails();
		sc=new Scanner(System.in);
		
		while(true)
		{
			System.out.println(" ");
			System.out.println("****WELCOME****");
			System.out.println(" ");
		System.out.println("Kindly!! Select Your Choice");
		System.out.println(" ");
		System.out.println("1. Create Account");
		System.out.println("2. Balance Enquiry ");
		System.out.println("3. Deposit balance");
		System.out.println("4. Withdraw Cash");
		System.out.println("5. Fund Transfer");
		//System.out.println("6. Mini statement");
		int a=0;
		a=sc.nextInt();
		switch(a)
		{
		case 1:
			Random ran=new Random();
			int accno=ran.nextInt(2000);
			System.out.println("Enter the Customer Name");
			String name=sc.next();
			boolean res1=service.validateCustomerName(name);
			try
			{
				if(res1==false)
				{
					throw new BankException("Invalid Name");
					}
					else {
						System.out.println("Continue");
					}
				{
			System.out.println("Enter the BranchName");
			String branch=sc.next();
			boolean res2=service.ValidateBranch(branch);
			try
			{	
				if(res2==false)
				{
					throw new BankException("Invalid Branch Name");
					}
					else {
						System.out.println("Continue");
					}
					{
			System.out.println("Enter your Mobile Number");
			String mobile=sc.next();
			boolean res3=service.ValidateCustomerMobileno(mobile);
			try
			{
				if(res3==false)
				{
					throw new BankException("Invalid Number");
					}
					else {
						System.out.println("Continue");
					}	
				{
			System.out.println("Enter The Account Balance");
			Double balance=sc.nextDouble();
			AccountDetails ab=new AccountDetails(name,branch,mobile,balance);
			service.addcustomer(accno,ab);
			System.out.println("****Success!!******");
			System.out.println("__Account Created Successfully__");
			System.out.println("Name: " +name);
			System.out.println("Branch: "+branch);
			System.out.println("Mobile No: "+mobile);
			System.out.println("Account number: " +accno);
			System.out.println("Account Balance:"+balance);
			}}
			catch(Exception e)
			{
			System.out.println("Do not enter:"+e);
			}}}	
				catch (Exception e)
			{
					System.out.println("Do not Enter :"+e);	
			}			}	
			}
			catch (Exception e)
			{
				System.out.println("Do not Enter "+e);
			}
break;
		case 2:
		{	
			System.out.println("Enter Your Account Number To Get The Balance");
			int acc=sc.nextInt();
			//AccountDetails ab=new AccountDetails();
			AccountDetails	ab=service.showbalance(acc);
		System.out.println(ab.getCustomerName()+ " Your Account Balance Is: "+ab.getBalance());
			
		}
		break;
		
		
		case 3:
		{
			System.out.println("Enter Your Account Number To Deposit");
			int acc=sc.nextInt();
			AccountDetails ab=service.showbalance(acc);
			double d=ab.getBalance();
			System.out.println("Your Account Balance is: "+d);
			System.out.println("Enter the Amount To Deposited");
			double amt=sc.nextDouble();
			double res=ab.setBalance(d+amt);
			System.out.println("Account Balance is: "+res);	
		}
		break;
		
		case 4:
		{
			System.out.println("Enter Your Account Number To Withdraw");
			int acc=sc.nextInt();
			AccountDetails ab=service.showbalance(acc);
			double d=ab.getBalance();
			System.out.println("Your Account Balance is: "+d);
			System.out.println("Enter the Amount ");
			double wa=sc.nextDouble();
			if(d>wa)
			{
				double res=ab.setBalance(d-wa);
				System.out.println("Account Balance is: "+res);
			}
			else {
				System.out.println("Insufficient Balance");
			}
			}
		break;
		
		case 5:
		{
			System.out.println("Enter the Account Number to Transfer");
			int acc1=sc.nextInt();
			AccountDetails ab=service.showbalance(acc1);
			System.out.println(ab.getBalance());
			System.out.println("Enter The Amount to Transfer");
			double w=sc.nextDouble();
			double res=ab.getBalance()-w;
			System.out.println("Amount Has Been Debited ");
			System.out.println("Your Account Balance is: "+res);
			System.out.println("Enter the Account Number To Receive The Fund");
			int acc2=sc.nextInt();
			AccountDetails a1=service.showbalance(acc2);
			System.out.println(a1.getBalance());
			double res2=a1.getBalance()+w;
			System.out.println("Amount Has Been Credited to Account"+acc2 );
			System.out.println("Your Current Account Balance is: "+res2);
			}
		break;
		
		
	}
		}}}
