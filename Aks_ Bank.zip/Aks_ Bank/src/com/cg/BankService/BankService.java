package com.cg.BankService;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.cg.BankDAO.BankDAO;
import com.cg.BankDAO.IBankDAO;
import com.cg.dto.AccountDetails;

public class BankService implements IBankService {

	IBankDAO dao=new BankDAO();

	@Override
	public int addcustomer(Integer a, AccountDetails ab) {
		dao.addcustomer(a,ab);
		return 0;
	}

	@Override
	public AccountDetails showbalance(int acc) {
		AccountDetails ab=dao.showbalance(acc);
		return ab;
		
	}

	@Override
	public boolean validateCustomerName(String name) {
		Pattern p=Pattern.compile("[A-Z]{1}[a-z]{1,14}");
		Matcher ename=p.matcher(name);
			if(ename.matches())
		{
			return true;
		}
		
		return false;
	}

	@Override
	public boolean ValidateCustomerMobileno(String cid) {
		Pattern p=Pattern.compile("[9]{1}[0-9]{9}");
		Matcher m=p.matcher(cid);
		if(m.matches())
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean ValidateBranch(String name) {
		Pattern p=Pattern.compile("[A-Z]{1}[a-z]{1,14}");
		Matcher name1=p.matcher(name);
			if(name1.matches())
		{
			return true;
		}
		
		return false;
	}
}
