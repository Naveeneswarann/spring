package com.cg.BankService;

import com.cg.dto.AccountDetails;

public interface IBankService {
	public int addcustomer(Integer a,AccountDetails a1);
	public AccountDetails showbalance(int acc);
	public boolean validateCustomerName(String name);
	public boolean ValidateCustomerMobileno(String cid);
	 public boolean ValidateBranch(String name);
	
	
}
