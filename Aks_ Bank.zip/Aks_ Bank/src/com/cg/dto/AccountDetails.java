package com.cg.dto;

public class AccountDetails {

	private String CustomerName;
	
	private String MobileNo;
	private String BranchName;
	private double Balance;
	
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}
	public String getBranchName() {
		return BranchName;
	}
	public void setBranchName(String branchName) {
		BranchName = branchName;
	}
	public double getBalance() {
		return Balance;
	}
	public double setBalance(double Balance) {
		return Balance = Balance;
	}
	public AccountDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AccountDetails(String customerName, String mobileNo, String branchName, double balance) {
		super();
		CustomerName = customerName;
		MobileNo = mobileNo;
		BranchName = branchName;
		Balance = balance;
	}
	@Override
	public String toString() {
		return "AccountDetails [CustomerName=" + CustomerName + ", MobileNo=" + MobileNo + ", BranchName=" + BranchName
				+ ", Acc_Balance=" + Balance + "]";
	}
}
