package com.cg.util;

import java.util.HashMap;


import com.cg.dto.AccountDetails;



	public class Collection {

		static HashMap<Integer, AccountDetails> hs=null;
		static {
			hs=new HashMap<Integer, AccountDetails>();
			hs.put(1234, new AccountDetails("Akshaya", "MIPL", "9840502059", 55000d));
			hs.put(5678, new AccountDetails("Abi", "Ngl", "9840502069", 66000d));
			hs.put(8765, new AccountDetails("Aishu", "Delhi", "9840502079", 79000d));
			hs.put(4321, new AccountDetails("Sanju", "Tvl", "9840502089", 89000d));
}
		public static void addcustomer(Integer a, AccountDetails ab) {
			hs.put(a, ab); 
			
		}
		public static AccountDetails showbalance(int acc)
		{
			if(hs.containsKey(acc))
			{
				AccountDetails ab=hs.get(acc);
				return ab;
			}
			else
			return null;
			
			   }
		
		public static HashMap<Integer, AccountDetails> getAllDetials() {
			return hs;
		}
	}
