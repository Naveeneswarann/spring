package com.cg.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.BankDAO.BankDAO;
import com.cg.BankDAO.IBankDAO;

import com.cg.dto.AccountDetails;


public class BankDAOTest1 {

	IBankDAO dao=new BankDAO();
	@Before
	public void setUp() throws Exception {
		dao = new BankDAO();
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
	}
	@Test
	public void testAddCustomer() {

		AccountDetails ab = new AccountDetails("Anish","TVM","8056957706" ,55000d);

		int genId = dao.addcustomer(1234,ab);
         assertNotNull(genId);
	}
	}
	


